# Gwangju Dongsin High — Simple Website

싱글 파일 기반에서 확장한 **정적 사이트** 템플릿입니다.

## 구성
- `index.html` — 구조/콘텐츠
- `styles.css` — 테마/레이아웃(라이트·다크 모드)
- `script.js` — 메뉴 토글, 폼 검증, 단축키
- `assets/favicon.svg` — 파비콘

## 로컬 실행
1. 이 폴더를 그대로 다운로드
2. `index.html` 더블클릭 → 브라우저에서 열기

## GitHub Pages 배포(요약)
1. GitHub 새 저장소 생성(공개) → 파일 업로드
2. **Settings → Pages** → Branch: `main` / Root 선택 → Save
3. 발급 URL 접속(예: `https://USERNAME.github.io/REPO/`)
